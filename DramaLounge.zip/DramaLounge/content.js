(function () {
  const EXT_NAMESPACE = 'DramaLounge';

  // ————————————————————————————————————————————
  // Moods provided by moods.js
  // ————————————————————————————————————————————
  const moodLines = Object.assign({
    bored: [
      "I could watch paint dry faster than this tab loads...",
      "If yawns were currency, I’d be a billionaire.",
      "Is this tab buffering or is my soul?",
      "I’ve seen snails with more urgency."
    ],
    excited: [
      "YES! Finally, some action!",
      "Hold onto your tabs, things are getting interesting!",
      "This click? Cinematic masterpiece.",
      "DramaLounge is living for this moment!"
    ],
    judgy: [
      "Another ‘are you still there?’ moment, huh?",
      "Bold choice… ignoring the internet like that.",
      "Your idle time speaks volumes.",
      "I’d say ‘productivity’ but we both know the truth."
    ],
    clingy: [
      "Don’t leave me. Not like the others.",
      "We can work this out. Just stay a little longer.",
      "If you close this tab, I’ll miss you forever.",
      "You complete me… and my DOM tree."
    ],
    alert: [
      "Ah, the land of answers: Google!",
      "Detecting search energy. I repeat, search energy.",
      "Google vibes detected. Stay focused.",
      "Don’t let the algorithm seduce you."
    ]
  }, window.DramaLoungeMoods || {});

  // ————————————————————————————————————————————
  // Utility helpers
  // ————————————————————————————————————————————
  function sampleRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function log(message, data) {
    try {
      chrome.runtime.sendMessage({ type: 'DRAMALOUNGE_LOG', payload: { message, data } });
    } catch (_) {
      // ignore in case of CSP or context teardown
    }
  }

  // ————————————————————————————————————————————
  // Speech bubble UI
  // ————————————————————————————————————————————
  let activeBubble; // HTMLElement | undefined
  let hideTimerId; // number | undefined
  let activeOverlays = []; // Array<HTMLElement | { remove():void }>

  function ensureContainer() {
    // No container necessary; bubble is standalone
    return document.body || document.documentElement;
  }

  function createBubble(moodName, text) {
    const bubble = document.createElement('div');
    bubble.className = 'dramalounge-bubble dramalounge-bottom-right';
    bubble.setAttribute('data-mood', moodName);

    const header = document.createElement('div');
    header.className = 'dramalounge-header';

    const dot = document.createElement('span');
    dot.className = 'dramalounge-dot';
    dot.style.background = moodColor(moodName);

    const title = document.createElement('span');
    title.className = 'dramalounge-title';
    title.textContent = `${EXT_NAMESPACE}`;

    const close = document.createElement('button');
    close.className = 'dramalounge-close';
    close.setAttribute('aria-label', 'Close DramaLounge');
    close.textContent = '×';
    close.addEventListener('click', () => hideBubble());

    header.appendChild(dot);
    header.appendChild(title);

    const body = document.createElement('div');
    body.className = 'dramalounge-body';
    body.textContent = text;

    bubble.appendChild(header);
    bubble.appendChild(body);
    bubble.appendChild(close);

    return bubble;
  }

  function moodColor(moodName) {
    switch (moodName) {
      case 'bored': return '#94a3b8';
      case 'excited': return '#f59e0b';
      case 'jealous': return '#10b981';
      case 'judgy': return '#ef4444';
      case 'clingy': return '#8b5cf6';
      case 'alert': return '#0ea5e9';
      default: return '#0ea5e9';
    }
  }

  function showBubble(moodName, text, durationMs = 4000) {
    const host = ensureContainer();
    if (!host) return;

    if (activeBubble && activeBubble.parentNode) {
      activeBubble.parentNode.removeChild(activeBubble);
    }
    if (hideTimerId) {
      clearTimeout(hideTimerId);
    }

    const bubble = createBubble(moodName, text);
    host.appendChild(bubble);
    // trigger CSS transition
    requestAnimationFrame(() => bubble.classList.add('show'));

    activeBubble = bubble;
    hideTimerId = setTimeout(() => hideBubble(), durationMs);
  }

  function hideBubble() {
    if (!activeBubble) return;
    activeBubble.classList.remove('show');
    const bubbleToRemove = activeBubble;
    activeBubble = undefined;
    setTimeout(() => {
      if (bubbleToRemove && bubbleToRemove.parentNode) {
        bubbleToRemove.parentNode.removeChild(bubbleToRemove);
      }
    }, 200);
  }

  // ————————————————————————————————————————————
  // Sound player with caching
  // ————————————————————————————————————————————
  const soundCache = new Map(); // mood -> HTMLAudioElement

  const moodToFile = {
    happy: 'trumpet-fanfare.mp3',
    sad: 'violin.mp3',
    jealous: 'sulky-sigh.mp3',
    dramatic: 'sad-chime.mp3',
    // Fallback mappings if we ever want sounds for existing moods:
    excited: 'trumpet-fanfare.mp3',
    judgy: 'sulky-sigh.mp3',
    clingy: 'violin.mp3',
    alert: 'sad-chime.mp3',
    bored: 'sulky-sigh.mp3'
  };

  function getAudioForMood(moodName) {
    const file = moodToFile[moodName];
    if (!file) return null;
    if (soundCache.has(moodName)) return soundCache.get(moodName);
    try {
      const url = chrome.runtime.getURL(`audio/${file}`);
      const audio = new Audio(url);
      audio.preload = 'auto';
      audio.volume = 0.7;
      soundCache.set(moodName, audio);
      return audio;
    } catch (err) {
      console.warn('[DramaLounge] Missing or blocked audio for mood:', moodName, err);
      return null;
    }
  }

  function playSound(moodName) {
    try {
      const audio = getAudioForMood(moodName);
      if (!audio) {
        console.info(`[DramaLounge] No audio available for mood: ${moodName}`);
        return;
      }
      // Restart if still playing to keep it punchy
      audio.currentTime = 0;
      const playPromise = audio.play();
      if (playPromise && typeof playPromise.catch === 'function') {
        playPromise.catch(() => {
          // Likely blocked due to no user gesture; ignore quietly
        });
      }
    } catch (err) {
      console.info('[DramaLounge] Could not play sound:', moodName, err);
    }
  }

  // ————————————————————————————————————————————
  // Mood trigger API
  // ————————————————————————————————————————————
  function triggerMood(moodName, overrideText) {
    const lines = moodLines[moodName] || [];
    const text = overrideText || (lines.length ? sampleRandom(lines) : undefined);
    if (!text) return;
    console.log(`[DramaLounge] Mood: ${moodName} → "${text}"`);
    showBubble(moodName, text);
    playSound(moodName);
    triggerEffect(moodName);
  }

  // Expose for debugging and for easter egg overlay management
  window.DramaLounge = {
    triggerMood,
    registerOverlay: (overlayOrHandle) => {
      try { if (overlayOrHandle) activeOverlays.push(overlayOrHandle); } catch (_) {}
    },
    clearOverlays: () => clearActiveOverlays()
  };

  // ————————————————————————————————————————————
  // Visual Effects (auto-cleanup)
  // ————————————————————————————————————————————
  function triggerEffect(moodName) {
    // Clear previous overlays/effects before adding new
    clearActiveOverlays();
    switch (moodName) {
      case 'happy':
        activeOverlays.push(effectConfetti({ durationMs: 3000 }));
        break;
      case 'sad':
        activeOverlays.push(effectRain({ durationMs: 3500 }));
        break;
      case 'jealous':
        activeOverlays.push(effectTintShake({ durationMs: 2000 }));
        break;
      case 'dramatic':
        activeOverlays.push(effectVignetteFlash({ durationMs: 2500 }));
        break;
      default:
        break;
    }
  }

  function clearActiveOverlays() {
    activeOverlays.forEach(o => {
      try { typeof o?.remove === 'function' ? o.remove() : o?.parentNode?.removeChild(o); } catch (_) {}
    });
    activeOverlays = [];
  }

  function makeOverlay(tag = 'div') {
    const el = document.createElement(tag);
    el.className = 'dramalounge-overlay';
    el.style.position = 'fixed';
    el.style.left = '0';
    el.style.top = '0';
    el.style.width = '100vw';
    el.style.height = '100vh';
    el.style.zIndex = '2147483646';
    el.style.pointerEvents = 'none';
    return el;
  }

  // happy → confetti (Canvas)
  function effectConfetti({ durationMs = 3000 } = {}) {
    try {
      const canvas = makeOverlay('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      document.documentElement.appendChild(canvas);

      function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
      resize();

      const colors = ['#f59e0b', '#10b981', '#ef4444', '#3b82f6', '#8b5cf6', '#eab308'];
      const pieces = Array.from({ length: Math.max(120, Math.floor(window.innerWidth / 10)) }).map(() => ({
        x: Math.random() * canvas.width,
        y: -20 - Math.random() * canvas.height,
        w: 6 + Math.random() * 6,
        h: 8 + Math.random() * 10,
        color: colors[Math.floor(Math.random() * colors.length)],
        speed: 2 + Math.random() * 3,
        rot: Math.random() * Math.PI,
        rotSpeed: -0.2 + Math.random() * 0.4
      }));

      let rafId;
      const start = performance.now();
      const onResize = () => resize();
      window.addEventListener('resize', onResize);

      function draw(now) {
        const t = now - start;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        pieces.forEach(p => {
          p.y += p.speed;
          p.x += Math.sin((p.y + p.w) * 0.01) * 1.2;
          p.rot += p.rotSpeed * 0.1;
          if (p.y > canvas.height + 20) {
            p.y = -20;
            p.x = Math.random() * canvas.width;
          }
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rot);
          ctx.fillStyle = p.color;
          ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
          ctx.restore();
        });
        if (t < durationMs) rafId = requestAnimationFrame(draw);
        else cleanup();
      }

      function cleanup() {
        cancelAnimationFrame(rafId);
        window.removeEventListener('resize', onResize);
        canvas.remove();
      }

      rafId = requestAnimationFrame(draw);
      // Return overlay so we can clear aggressively
      return { remove: () => { try { cancelAnimationFrame(rafId); window.removeEventListener('resize', onResize); canvas.remove(); } catch (_) {} } };
    } catch (_) { /* noop */ }
  }

  // sad → rain overlay
  function effectRain({ durationMs = 3500 } = {}) {
    const overlay = makeOverlay('canvas');
    const ctx = overlay.getContext('2d');
    if (!ctx) return;
    document.documentElement.appendChild(overlay);

    function resize() {
      overlay.width = window.innerWidth;
      overlay.height = window.innerHeight;
    }
    resize();

    const drops = Array.from({ length: Math.max(120, Math.floor(window.innerWidth / 8)) }).map(() => ({
      x: Math.random() * overlay.width,
      y: Math.random() * overlay.height,
      len: 8 + Math.random() * 14,
      speed: 4 + Math.random() * 6,
      alpha: 0.2 + Math.random() * 0.3
    }));

    let rafId;
    const start = performance.now();
    const onResize = () => resize();
    window.addEventListener('resize', onResize);

    function draw(now) {
      const t = now - start;
      ctx.clearRect(0, 0, overlay.width, overlay.height);
      ctx.strokeStyle = 'rgba(59, 130, 246, 0.45)';
      ctx.lineWidth = 1.2;
      drops.forEach(d => {
        ctx.globalAlpha = d.alpha;
        ctx.beginPath();
        ctx.moveTo(d.x, d.y);
        ctx.lineTo(d.x + 1.5, d.y + d.len);
        ctx.stroke();
        d.y += d.speed;
        d.x += 0.6; // wind
        if (d.y > overlay.height) {
          d.y = -10;
          d.x = Math.random() * overlay.width;
        }
      });
      ctx.globalAlpha = 1;
      if (t < durationMs) rafId = requestAnimationFrame(draw);
      else cleanup();
    }

    function cleanup() {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
      overlay.remove();
    }

    rafId = requestAnimationFrame(draw);
    return { remove: () => { try { cancelAnimationFrame(rafId); window.removeEventListener('resize', onResize); overlay.remove(); } catch (_) {} } };
  }

  // jealous → tint + shake
  function effectTintShake({ durationMs = 2000 } = {}) {
    const tint = makeOverlay('div');
    tint.style.background = 'rgba(0,0,0,0.2)';
    document.documentElement.appendChild(tint);

    const shaker = document.documentElement;
    shaker.classList.add('dramalounge-shake');

    const timeout = setTimeout(() => cleanup(), durationMs);

    function cleanup() {
      clearTimeout(timeout);
      tint.remove();
      shaker.classList.remove('dramalounge-shake');
    }
    return { remove: () => { try { clearTimeout(timeout); tint.remove(); shaker.classList.remove('dramalounge-shake'); } catch (_) {} } };
  }

  // dramatic → flashing vignette
  function effectVignetteFlash({ durationMs = 2500 } = {}) {
    const vignette = makeOverlay('div');
    vignette.classList.add('dramalounge-vignette', 'dramalounge-flash');
    document.documentElement.appendChild(vignette);

    const timeout = setTimeout(() => cleanup(), durationMs);

    function cleanup() {
      clearTimeout(timeout);
      vignette.remove();
    }
    return { remove: () => { try { clearTimeout(timeout); vignette.remove(); } catch (_) {} } };
  }

  // ————————————————————————————————————————————
  // Event tracking
  // ————————————————————————————————————————————

  // Clicks → excited
  document.addEventListener('click', (e) => {
    console.log('[DramaLounge] Event: click', { x: e.clientX, y: e.clientY });
    triggerMood('happy');
  }, { capture: true });

  // Idle detection → judgy
  let lastInteractionTs = Date.now();
  let idleTimerId;
  const IDLE_THRESHOLD_MS = 15000; // 15s for demo

  function markInteraction() {
    lastInteractionTs = Date.now();
  }

  ['mousemove', 'keydown', 'scroll', 'touchstart', 'visibilitychange'].forEach(evt => {
    window.addEventListener(evt, markInteraction, { passive: true });
  });

  function checkIdle() {
    const idleFor = Date.now() - lastInteractionTs;
    if (idleFor >= IDLE_THRESHOLD_MS) {
      console.log('[DramaLounge] Event: idle', { idleMs: idleFor });
      triggerMood('sad');
      lastInteractionTs = Date.now();
    }
  }

  idleTimerId = setInterval(checkIdle, 3000);

  // Tab visibility changes → jealous when hidden, excited when visible
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      console.log('[DramaLounge] Event: tab_hidden');
      triggerMood('jealous');
    } else {
      console.log('[DramaLounge] Event: tab_visible');
      triggerMood('happy');
    }
  });

  // Exit attempts (beforeunload) → clingy
  window.addEventListener('beforeunload', () => {
    // Note: Most browsers severely limit UI on beforeunload; we just schedule a bubble
    console.log('[DramaLounge] Event: exit_attempt');
    triggerMood('dramatic');
  });

  // Google visits → alert
  try {
    const host = location.hostname.toLowerCase();
    if (host.includes('google.')) {
      console.log('[DramaLounge] Event: google_visit');
      triggerMood('jealous');
    }
  } catch (_) {
    // ignore
  }

  // Initial bored on slow load (fallback)
  setTimeout(() => {
    if (document.readyState !== 'complete') {
      console.log('[DramaLounge] Event: slow_load');
      triggerMood('sad');
    }
  }, 5000);
})();


