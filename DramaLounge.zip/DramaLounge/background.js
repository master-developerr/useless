// DramaLounge background service worker (Manifest V3)
// Placeholder for future functionality (e.g., persistent user settings, sound preloading, etc.)

chrome.runtime.onInstalled.addListener(() => {
  // Initial setup if needed
  // Could be used to set default options in storage
});

// Example message relay (not strictly required in v1)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'DRAMALOUNGE_LOG') {
    // Simply log for now; can be expanded for analytics
    // Note: service workers may suspend; logs not guaranteed to persist
    console.log('[DramaLounge]', message.payload);
    sendResponse({ ok: true });
  }
  // Let Chrome know we'll respond synchronously
  return false;
});


