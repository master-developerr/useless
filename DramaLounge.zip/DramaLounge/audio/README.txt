Place your audio files here:

- trumpet-fanfare.mp3   (happy / excited)
- violin.mp3            (sad / clingy)
- sulky-sigh.mp3        (jealous / bored / judgy)
- sad-chime.mp3         (dramatic / alert)

These files are referenced from content.js via chrome.runtime.getURL('audio/<name>.mp3').


