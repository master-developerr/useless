(function () {
  // Exact predefined texts per request
  const MOODS = {
    jealous: [
      'Oh… so you found a better tab?',
      'Don’t mind me, I’ll just… sit here. Alone. In the dark.',
      '(Sad piano sound) It’s okay, I guess…',
      'Oh, so Google’s your smart friend now?',
      'Ask me next time! I could’ve guessed!',
      '(pouting face animation)'
    ],
    sad: [
      'You’ve been quiet… did I say something wrong?',
      'Are you… ignoring me?',
      '(Tiny whimper sound)'
    ],
    happy: [
      'Yay! You’re back!',
      'That click was amazing!',
      'Your scrolling style is… elegant.',
      'You have such a nice scrolling style.',
      'That typing rhythm… smooth like jazz.',
      'Wow… you pressed that button like a pro.'
    ],
    dramatic: [
      'WAIT! I can change!',
      'Fine… go… see if I care…',
      'Promise me you’ll come back…',
      'NO! NOT AGAIN!'
    ]
  };

  // Expose globally so content/easter eggs can consume
  window.DramaLoungeMoods = MOODS;
})();


